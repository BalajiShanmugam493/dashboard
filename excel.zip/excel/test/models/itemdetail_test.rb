require 'test_helper'

class ItemdetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
