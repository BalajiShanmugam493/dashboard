class Itemstatus < ApplicationRecord
end
