class Itemdetail < ApplicationRecord
end
