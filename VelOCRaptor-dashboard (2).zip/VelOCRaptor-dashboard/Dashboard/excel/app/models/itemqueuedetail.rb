class Itemqueuedetail < ApplicationRecord
end
