require 'test_helper'

class ItemstatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
